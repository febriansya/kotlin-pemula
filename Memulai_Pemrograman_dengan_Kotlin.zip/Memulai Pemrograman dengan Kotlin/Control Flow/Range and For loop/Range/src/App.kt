// main function
fun main() {
    val rangeInt = 1..10
    print(rangeInt.step)
    val angka = 1..100 step 2
    println(angka.step)
    println(angka.first)
    println(angka.last)
}