// main function
fun main() {
    val color : Color = Color.RED
    val color2: Color = Color.BLUE
    val color3: Color = Color.GREEN
    print("$color $color2 $color3")

    val hewan:Hewan = Hewan.KAMBING
    val hewan1:Hewan = Hewan.KUCING
    val hewan2:Hewan = Hewan.KELINCI
    println("""
        hewan   = $hewan
        hewan yang pertama  = $hewan1
        hewan yang kedua = $hewan2
    """.trimIndent())
}

enum class Color{
    RED, GREEN, BLUE
}
enum class Hewan{
    KAMBING,KUCING,KELINCI
}
