// main function
fun main() {
    val fullName = getFullName(first = "Kotlin" , middle = " is ", last = "Awesome")
    println(fullName)
    val firstName  = getCallName("yan",12)
    println(firstName)
}

fun getFullName(first: String, middle: String, last: String): String {
    return "$first $middle $last"
}
fun getCallName(first:String,old:Int):Any{

    return println("yours first name is $first and your old is $old")
}