fun main() {
    val total = listOf(1, 2, 1, 3, 4, 5, 2, 3, 4, 5)
    val tes  = listOf(1,1,2,2,4,4,5,16,16)
    val hasil  = tes.distinct()
    val distinct = total.distinct()

    println(hasil)
    println(distinct)
}
