var message = "Kotlin"
var contact = "dicoding"

fun main() {
    println(::message.name)
    println(::contact.name)
    println(::message.get())
    println(::contact.get())

    ::message.set("Kotlin Academy")
    ::contact.set("say hello dicoding")
    println(::message.get())
    println(message)
    println(::contact.get())
    println(contact)
}