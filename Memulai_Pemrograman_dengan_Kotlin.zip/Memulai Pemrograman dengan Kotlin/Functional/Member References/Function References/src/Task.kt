fun main() {
    val numbers = 1.rangeTo(10)
    val evenNumbers = numbers.filter(Int::isEvenNumber)

    println(evenNumbers)

    val ganjilNomor = numbers.filter(Int::isGanjilNumber)
    println(ganjilNomor)
}

fun Int.isEvenNumber() = this % 2 == 0
fun Int.isGanjilNumber() = this % 2 == 1

