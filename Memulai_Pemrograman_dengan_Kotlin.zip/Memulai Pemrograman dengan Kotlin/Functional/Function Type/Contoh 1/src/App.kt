val sum: (Int, Int) -> Int = { valueA, valueB -> valueA + valueB }

val multiply: (Int, Int) -> Int = { valueA, valueB -> valueA * valueB }

val modulo:(Int, Int) -> Int = {valueA,valuB -> valueA*valuB }


fun main() {
    val sumResult = sum.invoke(10, 10)
    val multiplyResult = multiply.invoke(20, 20)
    val hasil = modulo.invoke(12,3)

    println(sumResult)
    println(multiplyResult)
    println(hasil)
}