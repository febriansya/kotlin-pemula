// main function
fun main() {
    val length = messageLength("Hello From lambda")
    println("Message length $length")
    val angka = sum(23)
    println("angka  = $angka ")

}

val messageLength = { message: String -> message.length }
val sum =  {angka:Int -> angka*12}