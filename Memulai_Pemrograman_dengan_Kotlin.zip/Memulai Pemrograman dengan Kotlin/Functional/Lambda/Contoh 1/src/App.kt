// main function
fun main() {
    printMessage("Hello From Lambda")
    presentation("kopi lambada")
}

val printMessage = { message: String -> println(message) }
val presentation = {pesan:String -> println(pesan)}