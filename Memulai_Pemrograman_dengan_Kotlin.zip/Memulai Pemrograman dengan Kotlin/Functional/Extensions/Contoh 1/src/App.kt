// main function
fun main() {
    10.printInt()
    "Dicoding".printName()
}

fun Int.printInt() {
    print("value $this")
}
fun String.printName(){
    print("name $this")
}