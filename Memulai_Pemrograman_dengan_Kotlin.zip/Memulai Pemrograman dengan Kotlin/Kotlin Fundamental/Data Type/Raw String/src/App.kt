// main function
fun main() {
    val line = """
        Line 1
        Line 2
        Line 3
        Line 4
    """.trimIndent()

    val example  = """
        < your smile
        < your success
        < your spirit
        < your brain
    """.trimMargin("<")
    println(line)
    println(example)
}