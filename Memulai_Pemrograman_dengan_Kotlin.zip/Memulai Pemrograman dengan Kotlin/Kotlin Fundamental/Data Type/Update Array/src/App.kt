// main function
fun main() {
    val intArray = intArrayOf(1, 3, 5, 7)  // [1, 3, 5, 7]
    intArray[2] = 11 // [1, 3, 11, 7]
    intArray[1] =13
    println(intArray[2])
    println(intArray[1])

//    array lamda
    val lamda = Array(10,{i: Int ->i*i })
    for (i in lamda){
        println(i)
    }
}