// type your solution here
fun main() {
    val statement = "Kotlin is \"Awesome!\""
    println(statement)
    val statement1 = "Dicoding is \'Awesome \uD83D\uDE0D\'"
    println(statement1)
}