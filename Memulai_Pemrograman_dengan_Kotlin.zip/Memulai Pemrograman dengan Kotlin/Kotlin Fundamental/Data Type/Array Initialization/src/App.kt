// main function
fun main() {
    val intArray = intArrayOf(1, 3, 5, 7)
    print(intArray[2])
    println(intArray[3])

    val ploatArray  = floatArrayOf(1.3F,5.2F)
    for (i in ploatArray){
        println(i)
    }
}