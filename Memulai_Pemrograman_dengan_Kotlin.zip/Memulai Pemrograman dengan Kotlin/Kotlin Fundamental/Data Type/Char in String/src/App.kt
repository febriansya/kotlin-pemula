// main function
fun main() {
    val text  = "Kotlin"
    for (char in text){
        print("$char ")
    }

    val tesKata = "saya suka dicoding"
    for (suka in tesKata){
        print(suka)
    }
}