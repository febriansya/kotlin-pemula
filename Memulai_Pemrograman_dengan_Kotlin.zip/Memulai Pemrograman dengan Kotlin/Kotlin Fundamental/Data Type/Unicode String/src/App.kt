// main function
fun main() {
    val name = "Unicode test: \u0394"
    val name1 = "love dicoding and bangkit : \uD83D\uDE0D"
    print(name + name1)
}