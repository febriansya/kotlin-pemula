fun main() {
    val text: String? = null
    val textLength = text?.length ?: 7

    val textLenght  = if (text !=null ) text.length else 7
   println(textLenght)
    println(textLength)
}