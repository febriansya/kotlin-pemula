fun main() {
    val text: String? = null
    text?.length
    val textLength = text?.length ?: 7
    println(textLength)
//    val textLength = if (text != null) text.length else 7
    println(text)
}