// main function
fun main() {
    val name = "Alfian"

    print("Hello my name is ")
    println(name)
    print(if (true) "Always true" else "Always false")
}
/*
   output:
       Hello my name is Alfian
       Always true
*/