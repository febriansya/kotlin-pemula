// main function
fun main() {
    val officeOpen = 7
    val now = 20
    if (now > officeOpen) {
        println("office already open")
    }
    old(23)
}

fun old(old:Int){

    if (old <=10){
    println("umur ente belum cukup")
    }else{
        println("umur ente sudah cukup")
    }
}