// main function
fun main() {
    val officeOpen = 7
    val now = 20
    val office: String
    office = if (now > officeOpen) {
        "Office already open"
    } else {
        "Office is closed"
    }
    print(office)

    val hasil:String
    hasil  = if (now < 30){
        "not respond"
    }else if (now > officeOpen){
        if (officeOpen < 20){
            "yoi"
        }else{
            "beda"
        }
    }else{
        "yoyo"
    }
    print(hasil)
}