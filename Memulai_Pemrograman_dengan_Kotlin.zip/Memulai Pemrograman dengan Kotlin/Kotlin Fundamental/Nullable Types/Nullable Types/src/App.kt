fun main() {
    val text: String? = null

    //val textLength = text.length // compile time error
    if (text != null){
        val textLength = text.length // ready to go
    }

    val bolehNull:String?= null

    if (bolehNull == null){
        println("variabel masih null")
    }else{
        println("lanjutkan")
    }

}