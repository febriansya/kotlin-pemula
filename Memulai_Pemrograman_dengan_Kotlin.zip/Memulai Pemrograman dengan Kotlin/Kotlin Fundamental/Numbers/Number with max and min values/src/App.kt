
fun main() {
    val maxInt = Int.MAX_VALUE
    val minInt = Int.MIN_VALUE
    val maxFloat= Float.MAX_VALUE
    val minFloat= Float.MIN_VALUE
    println(maxInt)
    println(minInt)
    println(maxFloat)
    println(minFloat)

//
}