fun main() {
    val numberOne = 1
    val numberTwo = 2
    val exampleNUmber = 2/3
    println(numberOne + numberTwo)

    println(numberOne / numberTwo)
    println(exampleNUmber)
    println(5 + 4 * 4)
    println((5 + 4) * 4)
    println(7*4-6)
    println((7*4)-6)


}