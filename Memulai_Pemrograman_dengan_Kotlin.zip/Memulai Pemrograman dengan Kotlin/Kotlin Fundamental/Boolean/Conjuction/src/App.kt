// main function
fun main() {
    val officeOpen = 7
    val officeClosed = 16
    val now = 20

    val isOpen = now >= officeOpen && now <= officeClosed
    val close = now <= officeClosed && now <= officeOpen
    print("Office is open : $isOpen")
    print(close)
}