import kotlinx.coroutines.*

fun main() = runBlocking {
    val job = launch {
        delay(5000)
        println("Start new job!")
    }
    val working = launch {
        delay(3000)
        println("get started new job")
    }

    delay(1000)
    working.cancel()
    println("working has cancelled")
    when( working.isCancelled){
        true -> "working is canceled"
        else -> "thankyou"
    }

    delay(2000)
    job.cancel()
    println("Cancelling job...")
    if (job.isCancelled){
        println("Job is cancelled")
    }
}