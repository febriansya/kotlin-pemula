import kotlinx.coroutines.*

fun main() = runBlocking {
    val job = launch(start = CoroutineStart.LAZY) {
        delay(1000L)
        println("Start new job!")
    }
// menunggu proses selesai baru dinjalankan
    job.join()
    println("Other task")
}