import kotlinx.coroutines.*

fun main() = runBlocking {
    val job = launch(start = CoroutineStart.LAZY) {
        delay(1000L)
        println("Start new job!")
    }
    val work  = launch(start = CoroutineStart.LAZY){
        delay(1000L)
        println("start new JOB")
    }

    work.start()
    println("welcome to the VILLAGE")
    job.start()
    println("Other task")
}