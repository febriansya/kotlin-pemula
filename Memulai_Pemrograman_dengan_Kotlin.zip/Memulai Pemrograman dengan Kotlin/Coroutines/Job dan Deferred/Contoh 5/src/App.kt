import kotlinx.coroutines.*

suspend fun getCapital(): Int {
    delay(1000L)
    return 50000
}

suspend fun getIncome(): Int {
    delay(1000L)
    return 75000
}

suspend fun getProbabilitas():Int{
    delay(1000L)
    return 7000
}
fun main() = runBlocking {
    val capital = async { getCapital() }
    val income = async { getIncome() }
    val probstat = getProbabilitas()
    println("Your profit is ${income.await() - capital.await()}")
    println(probstat)
}