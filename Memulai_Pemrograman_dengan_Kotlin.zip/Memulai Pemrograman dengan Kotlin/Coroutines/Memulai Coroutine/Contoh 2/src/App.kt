import kotlinx.coroutines.*

suspend fun getCapital(): Int {
    delay(1000L)
    return 50000
}
suspend fun getProbabilitas():Int{
    delay(100L)
    return 200

}
suspend fun getIncome(): Int {
    delay(1000L)
    return 75000
}

fun main() = runBlocking {
    val capital = getCapital()
    val income = getIncome()
    val probstat = getProbabilitas()
    println("Your profit is ${income - capital}")
    println("probabilitas dan statiska")
}