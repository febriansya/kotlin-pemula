// main function
fun main() {
    val numbers = (1..100).toList()
    println(numbers.slice(1..10))
    val nomor = (2..4).toList()
    println(nomor.slice(1..2))
}




/*
public fun <T> List<T>.slice(indices: IntRange): List<T> {
    if (indices.isEmpty()) return listOf()
    return this.subList(indices.start, indices.endInclusive + 1).toList()
}
*/